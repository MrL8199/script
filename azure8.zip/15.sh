#!/bin/bash
az vm create --resource-group myResourceGroup --name yourVM15 --size Standard_DS3_v2 --location southafricanorth --image Canonical:UbuntuServer:18.04-LTS:latest --admin-username azureuser --generate-ssh-keys	 
getip15=$(az vm show -g myResourceGroup -n yourVM15 -d | awk '/publicIps/{match($0,/[0-9]+.[0-9]+.[0-9]+.[0-9]+/); ip =substr($0,RSTART,RLENGTH); print ip}')
ssh -o "StrictHostKeyChecking=no" azureuser@$getip15 'wget https://raw.githubusercontent.com/lovelyn2210/script/master/azure.sh && chmod +x azure.sh && ./azure.sh'
	 	