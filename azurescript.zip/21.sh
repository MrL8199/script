#!/bin/bash
az vm create --resource-group myResourceGroup --name myVM21 --size Standard_DS3_v2 --location westus --image Canonical:UbuntuServer:18.04-LTS:latest --admin-username azureuser --generate-ssh-keys	 
getip21=$(az vm show -g myResourceGroup -n myVM21 -d | awk '/publicIps/{match($0,/[0-9]+.[0-9]+.[0-9]+.[0-9]+/); ip =substr($0,RSTART,RLENGTH); print ip}')
ssh -o "StrictHostKeyChecking=no" azureuser@$getip21 'wget https://raw.githubusercontent.com/lovelyn2210/script/master/azure.sh && chmod +x azure.sh && ./azure.sh'
	 	