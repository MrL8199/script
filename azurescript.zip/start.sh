#!/bin/sh
az group create --name myResourceGroup --location eastus

sh 1.sh &
sh 2.sh &
sh 3.sh &
sh 4.sh &
sh 5.sh &
sh 6.sh &
sh 7.sh &
sh 8.sh &
sh 9.sh &
sh 10.sh &
sh 11.sh &
sh 12.sh 
sh 13.sh &
sh 14.sh &
sh 15.sh &
sh 16.sh &
sh 17.sh &
sh 18.sh &
sh 19.sh &
sh 20.sh &
sh 21.sh &
sh 22.sh &
sh 23.sh &
